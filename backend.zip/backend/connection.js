// Importing the 'mongoose' module, which is an ODM (Object Data Modeling) library for MongoDB and Node.js
const mongoose = require('mongoose');

// Function to connect to MongoDB using Mongoose
// Takes a MongoDB connection URL as an argument
async function connectionmongoDB(url) {
    // Attempting to connect to the provided MongoDB URL
    // If successful, logs 'connection started', otherwise logs 'connection not started'
    return mongoose.connect(url)
        .then(() => console.log('connection started'))  // Success handler
        .catch(() => console.log('connection not started')); // Error handler
}

// Exporting the connection function for use in other parts of the application
module.exports = {
    connectionmongoDB
};

const express = require('express');
const { connectionmongoDB } = require("./connection");
const fileUpload = require('express-fileupload');
const cors = require("cors");
const morgan = require("morgan");
const { Server } = require('socket.io');
const http = require('http');

// CORS configuration to allow requests from any origin
const corsOptions = {
    origin: true,
    credentials: true,
    optionSuccessStatus: 201
};

const app = express();
const PORT = process.env.PORT || 3000;

// Connecting to MongoDB database
connectionmongoDB("mongodb://localhost:27017/disaster");

// Middleware setup
app.use(express.json()); // Parse incoming JSON requests
app.use(fileUpload()); // Enable file uploads
app.use(cors(corsOptions)); // Enable CORS for cross-origin requests
app.use(express.urlencoded({limit: '10mb', extended: true })); // Parse URL-encoded data with limit
app.use(morgan("dev")); // Logging HTTP requests
app.use(express.static("./public")); // Serve static files from the "public" directory

// Create an HTTP server for socket.io
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*", // Allow requests from any origin
        methods: ["GET", "POST"] // Allow only GET and POST methods
    }
});

// Attach the socket.io instance to the Express app
app.set('io', io);

// Store active rooms and connected users
let activeRooms = {};

// Handle socket.io connections
io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // User joins a room based on context_id (e.g., a study group or discussion room)
    socket.on('joinRoom', (context_id) => {
        if (!context_id) {
            console.error('Invalid context_id');
            return;
        }
        console.log(`User with socket.id ${socket.id} joining room: ${context_id}`);
        socket.join(context_id);

        // Maintain a list of active users in each room
        if (!activeRooms[context_id]) {
            activeRooms[context_id] = [];
        }
        activeRooms[context_id].push(socket.id);

        // Notify the user that they have joined the room
        socket.emit("joinedRoom", context_id);
        console.log(`Users in room ${context_id}: ${activeRooms[context_id].join(", ")}`);

        // If there are exactly 5 users in the room, notify them to start a call
        if (activeRooms[context_id].length === 5) {
            io.to(context_id).emit('startCall', context_id);
        }
    });

    // Broadcast typing event when a user is typing
    socket.on('typing', (context_id, userId) => {
        socket.broadcast.to(context_id).emit('userTyping', userId);
    });

    // Handle incoming call event
    socket.on('incomingCall', (callerId, context_id) => {
        if (!context_id) {
            console.error('Context ID is missing when sending incoming call');
            return;
        }
        console.log(`Incoming call from ${callerId} to room ${context_id}`);
        socket.broadcast.to(context_id).emit('incomingCall', { callerId, context_id });
    });

    // Handle user disconnection
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);

        // Remove the user from active rooms
        for (let context_id in activeRooms) {
            const index = activeRooms[context_id].indexOf(socket.id);
            if (index !== -1) {
                activeRooms[context_id].splice(index, 1);
                console.log(`User removed from room ${context_id}. Users remaining: ${activeRooms[context_id].join(", ")}`);
            }
        }
    });
});

// Root endpoint to check if the server is running
app.get('/', (req, res) => {
    res.send('Hello, World!');
});

// API Routes
app.use("/api/user", require("./routes/userroutes")); // User-related routes
app.use("/api/program", require("./routes/organizationroutes")); // Organization-related routes
app.use("/api/chats", require("./routes/chatsRoutes")); // Chat-related routes
app.use("/api/fund", require("./routes/fundroutes")); // Fundraising-related routes

// Start the server
server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

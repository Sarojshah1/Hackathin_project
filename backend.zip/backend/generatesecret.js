// Importing the 'crypto' module which provides cryptographic functionality
const crypto = require('crypto');

// Generating a random 64-byte string and converting it to hexadecimal format
// This will be used as a secret key for cryptographic purposes or for securing data
const secret = crypto.randomBytes(64).toString('hex');

// Outputting the generated secret to the console
console.log(secret);

const express = require("express");
const router = express.Router();
const fundraisingController = require("../controllers/fundcontrollers");

// Create a new fundraising campaign
router.post("/", fundraisingController.createFundraising);

// Get all fundraising campaigns
router.get("/", fundraisingController.getAllFundraisings);

// Get a specific fundraising campaign by ID
router.get("/:id", fundraisingController.getFundraisingById);

// Update a fundraising campaign
router.put("/:id", fundraisingController.updateFundraising);

// Delete a fundraising campaign
router.delete("/:id", fundraisingController.deleteFundraising);

// Donate to a fundraising campaign
router.post("/:id/donate", fundraisingController.donateToFundraising);

module.exports = router;

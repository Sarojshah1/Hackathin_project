const express = require("express");
const router = express.Router();
const programController = require("../controllers/organizationcontrolers");
const { verifyToken } = require("../middlewares/Auth");

router.post("/create", verifyToken, programController.createProgram); // Create a new program
router.get("/",  programController.getAllPrograms); // Get all programs (Protected)
router.get("/:id", verifyToken, programController.getProgramById); // Get program by ID (Protected)
router.put("/:id", verifyToken, programController.updateProgram); // Update program details (Protected)
router.delete("/:id", verifyToken, programController.deleteProgram); // Delete program (Protected)

module.exports = router;

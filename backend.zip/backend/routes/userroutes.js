const express = require("express");
const router = express.Router();
const userController = require("../controllers/userControllers");  // Importing the user controller
const {verifyToken} = require("../middlewares/Auth");  // Importing the verifyToken middleware

// Register a new user
router.post("/register", userController.registerUser); // Register user

// Login a user
router.post("/login", userController.loginUser); // Login user

// Get all users (Protected route, requires authentication)
router.get("/", verifyToken, userController.getAllUsers); // Get all users (Protected)

// Get a user by ID (Protected route, requires authentication)
router.get("/:id", verifyToken, userController.getUserById); // Get user by ID (Protected)

// Update user profile (Protected route, requires authentication)
router.put("/:id", verifyToken, userController.updateUser); // Update user profile (Protected)

// Delete a user (Protected route, requires authentication)
router.delete("/:id", verifyToken, userController.deleteUser); // Delete user (Protected)

// Get the current user's profile (Protected route, requires authentication)
router.get("/profile", verifyToken, userController.getUserProfile);

module.exports = router;  // Export the router for use in other files

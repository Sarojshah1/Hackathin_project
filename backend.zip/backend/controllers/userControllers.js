// Importing required modules
const User = require("../models/users");  // Importing the User model
const path = require('path');  // Importing the path module to handle file paths
const fs = require('fs');  // Importing the fs (file system) module to interact with the file system
const bcrypt = require("bcryptjs");  // Importing bcrypt for password hashing
const jwt = require("jsonwebtoken");  // Importing jwt for generating JSON Web Tokens

// User registration
exports.registerUser = async (req, res) => {
    try {
        // Destructuring the user data from the request body
        const { name, email, password, role, bio, contact_number, address } = req.body;
        console.log(req.body)  // Logging the request body for debugging
        let profilePhoto = null;

        // Check if the email is already registered
        const existingUser = await User.findOne({ email });
        if (existingUser) return res.status(400).json({ success: false, message: "Email already registered" });

        // Handling file upload for profile picture if provided
        if (req.files && req.files.profile_picture) {
            const { profile_picture } = req.files;
            profilePhoto = `photo-${Date.now()}-${profile_picture.name}`;  // Generating a unique name for the profile picture
            const uploadPath = path.join(__dirname, `../public/${profilePhoto}`);  // Defining the path to save the image
            const directoryPath = path.join(__dirname, '../public');  // Directory where images will be stored

            // Create the directory if it doesn't exist
            if (!fs.existsSync(directoryPath)) {
                fs.mkdirSync(directoryPath, { recursive: true });
            }

            // Move the uploaded image to the specified path
            await profile_picture.mv(uploadPath);
        }

        // Hashing the password before saving it to the database
        const hashedPassword = await bcrypt.hash(password, 10);

        // Creating a new user object
        const newUser = new User({
            name,
            email,
            password: hashedPassword,
            role,
            profile_picture: profilePhoto,
            bio,
            contact_number,
            address,
        });

        // Saving the new user to the database
        await newUser.save();
        res.status(201).json({ success: true, message: "User registered successfully", user: newUser });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// User Login
exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Finding the user by email
        const user = await User.findOne({ email });
        if (!user) return res.status(404).json({ success: false, message: "User not found" });

        // Comparing the provided password with the hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ success: false, message: "Invalid credentials" });

        // Generating a JWT token for the user
        const token = jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET);

        res.status(200).json({ success: true, message: "Login successful", token, user });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Get all users (admin functionality)
exports.getAllUsers = async (req, res) => {
    try {
        // Fetching all users and excluding their passwords
        const users = await User.find().select("-password");  // Excluding passwords from the response
        res.status(200).json({ success: true, users });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Get user by ID (view profile)
exports.getUserById = async (req, res) => {
    try {
        // Finding the user by their ID and excluding the password field
        const user = await User.findById(req.user._id).select("-password");
        if (!user) return res.status(404).json({ success: false, message: "User not found" });

        res.status(200).json({ success: true, user });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Update user profile
exports.updateUser = async (req, res) => {
    try {
        const { name, profile_picture, bio, contact_number, address } = req.body;

        // Updating user data
        const updatedUser = await User.findByIdAndUpdate(
            req.params.id,  // The ID of the user to be updated
            { name, profile_picture, bio, contact_number, address, updated_at: Date.now() },  // New data
            { new: true }  // Return the updated user
        ).select("-password");

        if (!updatedUser) return res.status(404).json({ success: false, message: "User not found" });

        res.status(200).json({ success: true, message: "Profile updated successfully", user: updatedUser });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Delete user
exports.deleteUser = async (req, res) => {
    try {
        // Deleting the user by ID
        const deletedUser = await User.findByIdAndDelete(req.params.id);
        if (!deletedUser) return res.status(404).json({ success: false, message: "User not found" });

        res.status(200).json({ success: true, message: "User deleted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// Get user profile
exports.getUserProfile = async (req, res) => {
    try {
        // Check if the user ID exists in the request object
        if (!req.user || !req.user._id) {
            return res.status(400).json({ message: 'User ID missing in request' });
        }

        // Fetching the user's profile and excluding the password field
        const user = await User.findById(req.user._id).select('-password');
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }

        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching user profile.', error });
    }
};

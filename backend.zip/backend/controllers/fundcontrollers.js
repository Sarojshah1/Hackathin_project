// Importing necessary modules
const Fundraising = require("../models/fundModel");
const Organization = require("../models/organizationmodel");
const path = require("path");
const fs = require("fs");

// Create a new fundraising campaign
exports.createFundraising = async (req, res) => {
    try {
        // Extracting the fields from the request body
        const { title, description, targetAmount, deadline } = req.body;

        let imageUrls = null;


        // Handling image upload for the fundraising campaign
        if (req.files && req.files.imageUrl) {
            const { imageUrl } = req.files;
            imageUrls = `fundraising-${Date.now()}-${imageUrl.name}`; // Generating a unique name for the image
            const uploadPath = path.join(__dirname, `../public/${imageUrls}`);
            const directoryPath = path.join(__dirname, "../public");
            // Creating the directory if it doesn't exist
            if (!fs.existsSync(directoryPath)) {
                fs.mkdirSync(directoryPath, { recursive: true });
            }
            // Moving the uploaded image to the server
            await imageUrl.mv(uploadPath);
        }

        // Creating a new fundraising campaign with the provided data
        const newFundraising = new Fundraising({
            title,
            description,
            targetAmount,
            collectedAmount: 0, // Initial collected amount is 0
            deadline,
            imageUrl: imageUrls,
        });

        // Saving the new fundraising campaign to the database
        await newFundraising.save();
        res.status(201).json({ success: true, message: "Fundraising campaign created successfully", fundraising: newFundraising });
    } catch (error) {
        console.log(error); // Log any error for debugging
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Get all fundraising campaigns
exports.getAllFundraisings = async (req, res) => {
    try {
        const fundraisings = await Fundraising.find();
        if (!fundraisings.length) {
            return res.status(404).json({ success: false, message: "No fundraising campaigns found" });
        }

        res.status(200).json({ success: true, fundraisings });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Get a specific fundraising campaign by ID
exports.getFundraisingById = async (req, res) => {
    try {
        // Find the fundraising campaign by ID
        const fundraising = await Fundraising.findById(req.params.id).populate("orgId");
        if (!fundraising) {
            return res.status(404).json({ success: false, message: "Fundraising campaign not found" });
        }

        res.status(200).json({ success: true, fundraising });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Update a fundraising campaign
exports.updateFundraising = async (req, res) => {
    try {
        const { title, description, targetAmount, deadline, imageUrl } = req.body;

        // Updating the fundraising campaign by ID
        const updatedFundraising = await Fundraising.findByIdAndUpdate(
            req.params.id,
            { title, description, targetAmount, deadline, imageUrl, updatedAt: Date.now() },
            { new: true } // Return the updated document
        );

        if (!updatedFundraising) {
            return res.status(404).json({ success: false, message: "Fundraising campaign not found" });
        }

        res.status(200).json({ success: true, message: "Fundraising campaign updated successfully", fundraising: updatedFundraising });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Delete a fundraising campaign
exports.deleteFundraising = async (req, res) => {
    try {
        // Deleting the fundraising campaign by ID
        const deletedFundraising = await Fundraising.findByIdAndDelete(req.params.id);
        if (!deletedFundraising) {
            return res.status(404).json({ success: false, message: "Fundraising campaign not found" });
        }

        res.status(200).json({ success: true, message: "Fundraising campaign deleted successfully" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Donate to a fundraising campaign
exports.donateToFundraising = async (req, res) => {
    try {
        const { donationAmount } = req.body;

        // Validate the donation amount
        if (!donationAmount || donationAmount <= 0) {
            return res.status(400).json({ success: false, message: "Invalid donation amount" });
        }

        // Find the fundraising campaign by ID
        const fundraising = await Fundraising.findById(req.params.id);
        if (!fundraising) {
            return res.status(404).json({ success: false, message: "Fundraising campaign not found" });
        }

        // Update the collected amount
        fundraising.collectedAmount += donationAmount;

        // Ensure that collected amount does not exceed the target amount
        if (fundraising.collectedAmount > fundraising.targetAmount) {
            fundraising.collectedAmount = fundraising.targetAmount;
        }

        // Save the updated fundraising campaign
        await fundraising.save();

        res.status(200).json({ success: true, message: "Donation successful", fundraising });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });
    }
};

// Import necessary dependencies
const Program = require("../models/organizationmodel"); // Import Program model
const path = require('path'); // Path module for handling file paths
const fs = require('fs'); // File system module for interacting with file system
const nodemailer = require("nodemailer"); // Nodemailer for sending emails
const User = require("../models/users"); // Import User model

// Function to send emails to all users about the new program
const sendEmailToUsers = async (program) => {
    try {
        // Fetch all users from the database
        const users = await User.find();
        // Extract the email addresses of the users
        const userEmails = users.map(user => user.email);

        // Create a transporter object for sending email using Gmail's SMTP server
        const transporter = nodemailer.createTransport({
            service: 'gmail',  // Gmail service
            host: "smtp.gmail.com",  // SMTP server for Gmail
            port: 587,  // Port to use for sending the email
            secure: false,  // Not using SSL/TLS
            auth: {
                user: process.env.USER,  // Sender's Gmail address from environment variables
                pass: process.env.APP_PASSWORD,  // Sender's Gmail app-specific password from environment variables
            },
        });

        // Email content with program details formatted in HTML
        const emailContent = `
            <h2>Subject: New Program Alert - ${program.name}</h2>
            <p>Dear valued members,</p>
            <p>We are pleased to inform you about a new program that has been launched by our organization. Below are the details:</p>
            <h3><strong>Program Name:</strong> ${program.name}</h3>
            <p><strong>Description:</strong> ${program.description}</p>
            <p>This initiative aims to address critical issues, provide support, and make a significant impact in the affected areas. Your involvement is vital in ensuring its success.</p>
            <p><strong>Contact Email:</strong> ${program.contactEmail}</p>
            <p><strong>Contact Phone:</strong> ${program.contactPhone}</p>
            <p><strong>Start Date:</strong> ${new Date(program.startDate).toLocaleDateString()}</p>
            <p><strong>End Date:</strong> ${new Date(program.endDate).toLocaleDateString()}</p>
            <p>Please do not hesitate to reach out for any inquiries or further details.</p>
            ${program.logoUrl ? `<p><img src="${program.logoUrl}" alt="Program Logo" style="max-width: 200px;" /></p>` : ""}
            <p>Thank you for your continued support. We look forward to working together on this important cause.</p>
            <p>Sincerely,</p>
            <p><strong>Your Organization's Name</strong></p>
            <p><em>For any queries or assistance, feel free to contact us directly.</em></p>
        `;

        // Loop through each email and send the program details
        userEmails.forEach(async (email) => {
            await transporter.sendMail({
                from: process.env.SMTP_MAIL,  // Sender's address
                to: email,  // Recipient's email address
                subject: `New Program Alert - ${program.name}`,  // Subject of the email
                html: emailContent,  // HTML content of the email
            });
        });
    } catch (error) {
        console.error("Error sending email:", error); // Catch and log any errors
    }
};

// Function to create a new program
exports.createProgram = async (req, res) => {
    try {
        const { name, description, contactEmail, contactPhone, endDate } = req.body;
        let logo = null;
        const startDate = new Date(); // Set current date as the start date

        // Check if a program with the same name already exists
        const existingProgram = await Program.findOne({ name });
        if (existingProgram) return res.status(400).json({ success: false, message: "Program already exists" });

        // Handle the logo file upload
        if (req.files && req.files.logoUrl) {
            const { logoUrl } = req.files;
            logo = `logo-${Date.now()}-${logoUrl.name}`;  // Unique logo file name
            const uploadPath = path.join(__dirname, `../public/${logo}`);  // Path where logo will be saved
            const directoryPath = path.join(__dirname, '../public');  // Directory for storing logo files
            // Check if directory exists, if not, create it
            if (!fs.existsSync(directoryPath)) {
                fs.mkdirSync(directoryPath, { recursive: true });
            }
            // Move the logo file to the designated path
            await logoUrl.mv(uploadPath);
        }

        // Create a new program in the database
        const newProgram = new Program({
            name,
            description,
            contactEmail,
            contactPhone,
            logoUrl: logo,
            startDate,
            endDate,
        });

        await newProgram.save(); // Save the new program in the database

        // Send an email to all users about the new program
        sendEmailToUsers(newProgram);

        // Return a response to the client with program details
        res.status(201).json({ success: true, message: "Program created successfully", program: newProgram });
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });  // Error handling
    }
};

// Function to get all programs from the database
exports.getAllPrograms = async (req, res) => {
    try {
        const programs = await Program.find();
        if (!programs.length) {
            return res.status(404).json({ success: false, message: "No programs found" });  // No programs found
        }
        res.status(200).json({ success: true, programs });  // Return all programs
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });  // Error handling
    }
};

// Function to get a single program by its ID
exports.getProgramById = async (req, res) => {
    try {
        const program = await Program.findById(req.params.id);
        if (!program) return res.status(404).json({ success: false, message: "Program not found" });  // Program not found

        res.status(200).json({ success: true, program });  // Return the program details
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });  // Error handling
    }
};

// Function to update an existing program
exports.updateProgram = async (req, res) => {
    try {
        const { name, description, contactEmail, contactPhone, startDate, endDate, logoUrl } = req.body;

        const updatedProgram = await Program.findByIdAndUpdate(
            req.params.id,
            { name, description, contactEmail, contactPhone, startDate, endDate, logoUrl, updatedAt: Date.now() }, // Update fields
            { new: true, runValidators: true }  // Return the updated program and validate changes
        );

        if (!updatedProgram) return res.status(404).json({ success: false, message: "Program not found" });  // Program not found

        res.status(200).json({ success: true, message: "Program updated successfully", program: updatedProgram });  // Return updated program details
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });  // Error handling
    }
};

// Function to delete a program by its ID
exports.deleteProgram = async (req, res) => {
    try {
        const deletedProgram = await Program.findByIdAndDelete(req.params.id);  // Delete program by ID
        if (!deletedProgram) return res.status(404).json({ success: false, message: "Program not found" });  // Program not found

        res.status(200).json({ success: true, message: "Program deleted successfully" });  // Program deleted
    } catch (error) {
        res.status(500).json({ success: false, message: "Internal server error" });  // Error handling
    }
};

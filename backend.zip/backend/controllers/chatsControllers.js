const Chat = require('../models/chats');
const io = require('../utils/socket');

// Create a new chat message
const createChatMessage = async (req, res) => {
    try {
        const { context_id, message_content } = req.body;
        const id = req.user._id; // Accessing the user ID from the request object
        console.log(id); // Debugging user ID (can be removed in production)

        // Check if both context_id and message_content are provided in the request body
        if (!context_id || !message_content) {
            return res.status(400).json({ message: 'All fields are required.' });
        }

        // Create a new chat message with the provided context, sender ID, and message content
        const newChat = new Chat({
            context_id,
            sender_id: req.user._id,
            message_content,
        });

        // Save the new chat message to the database
        const savedChat = await newChat.save();

        // Populate the sender's details (name, email, profile picture) in the saved chat
        await savedChat.populate('sender_id', 'name email profile_picture');

        // Access the socket.io instance and emit the new message to the specified context (room)
        const io = req.app.get('io');
        io.to(context_id).emit('newMessage', savedChat);

        // Respond with the saved chat message
        return res.status(201).json(savedChat);
    } catch (error) {
        // Handle any errors and return a 500 response with the error message
        return res.status(500).json({ message: 'Error creating chat message', error: error.message });
    }
};

// Get all chat messages by context (e.g., chat room or conversation)
const getChatMessagesByContext = async (req, res) => {
    try {
        const { context_id } = req.params;

        // Check if context_id is provided as a URL parameter
        if (!context_id) {
            return res.status(400).json({ message: 'Context ID is required.' });
        }

        // Find all messages for the given context_id and populate sender details (name, email, profile picture)
        const messages = await Chat.find({ context_id }).populate('sender_id', 'name email profile_picture');

        // Respond with the retrieved messages
        return res.status(200).json(messages);
    } catch (error) {
        // Handle any errors and return a 500 response with the error message
        return res.status(500).json({ message: 'Error retrieving chat messages', error: error.message });
    }
};

module.exports = {
    createChatMessage,
    getChatMessagesByContext,
};

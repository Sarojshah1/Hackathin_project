const mongoose = require("mongoose");

const ProgramSchema = new mongoose.Schema({
    name: { type: String, required: true },  // Name of the program (required field)
    description: { type: String },  // A brief description of the program
    contactEmail: { type: String, required: true },  // Contact email (required field)
    contactPhone: { type: String },  // Contact phone number (optional)
    logoUrl: { type: String },  // URL of the program's logo (optional)
    startDate: { type: Date, required: true },  // Start date of the program (required field)
    endDate: { type: Date, required: true },  // End date of the program (required field)
    createdAt: { type: Date, default: Date.now },  // Timestamp of when the program was created (defaults to current date and time)
});

module.exports = mongoose.model("Program", ProgramSchema);  // Exporting the schema as a 'Program' model

// Importing the 'mongoose' module, which provides MongoDB object modeling functionality
const mongoose = require('mongoose');

// Defining the schema for the User model
const userSchema = new mongoose.Schema({
    // Name field: required string
    name: { type: String, required: true },

    // Email field: required string, must be unique
    email: { type: String, required: true, unique: true },

    // Password field: required string
    password: { type: String, required: true },

    // Profile picture field: optional string, default is null
    profile_picture: { type: String, default: null },

    // Bio field: optional string, default is an empty string
    bio: { type: String, default: '' },

    // Contact number field: optional string, default is an empty string
    contact_number: { type: String, default: '' },

    // Address field: optional string, default is an empty string
    address: { type: String, default: '' },

    // Role field: required string, must be either 'INGO' or 'Volunteer'
    role: { type: String, enum: ['INGO', 'Volunteer'], required: true },

    // Created date: automatically set to the current date when the document is created
    created_at: { type: Date, default: Date.now },

    // Updated date: automatically set to the current date when the document is created
    updated_at: { type: Date, default: Date.now },
});

// Middleware to update `updated_at` field before saving a document
// This ensures the `updated_at` field is always the latest timestamp when the document is modified
userSchema.pre('save', function (next) {
    this.updated_at = Date.now(); // Set the current timestamp
    next(); // Proceed to the next middleware or save operation
});

// Exporting the 'User' model based on the defined schema
// This makes it available for use in other parts of the application
module.exports = mongoose.model('User', userSchema);

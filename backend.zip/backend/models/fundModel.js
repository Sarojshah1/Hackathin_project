// Importing the mongoose library to interact with MongoDB
const mongoose = require("mongoose");

// Defining the schema for the Fundraising model
const FundraisingSchema = new mongoose.Schema({
    // Title of the fundraising campaign, required field
    title: { type: String, required: true },

    // Description of the fundraising campaign, optional field
    description: { type: String },

    // Target amount for fundraising, required field
    targetAmount: { type: Number, required: true },

    // Collected amount, initialized to 0 by default
    collectedAmount: { type: Number, default: 0 },

    // Deadline for the fundraising, required field
    deadline: { type: Date, required: true },

    // Optional field for an image URL (e.g., for a banner or image related to the fundraising campaign)
    imageUrl: { type: String },

    // Date when the fundraising campaign was created, default is the current date
    createdAt: { type: Date, default: Date.now },
});

// Exporting the Fundraising model using the schema defined above
module.exports = mongoose.model("Fundraising", FundraisingSchema);
